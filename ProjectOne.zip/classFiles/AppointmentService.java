package classFiles;
import java.util.*;

public class AppointmentService {
	//private static List<Appointment> appointments;
	HashMap<String, Appointment> appointments = new HashMap<String, Appointment >();
	
	//Constructor
	public AppointmentService() {
		appointments = new HashMap<String, Appointment>();
	}
	
	public boolean addAppointment(Appointment appointment) {
		boolean isSuccess = false;
		if(!appointments.containsKey(appointment.getId())) { //Add appointment if appointment's ID does not already exist
			appointments.put(appointment.getId(), appointment );
			isSuccess = true;
		}
		else {
			System.out.println("Appointment ID already exists");
		}
		return isSuccess;
	}
	
	public boolean deleteAppointment(Appointment appointment) {
		boolean isSuccess = false;
		if(appointments.containsKey(appointment.getId())) {
			appointments.remove(appointment);
			isSuccess = true;
		}
		else {
			System.out.println("Appointment ID not found"); //If appointment ID does not exist in map, display error message
		}
		return isSuccess;
	}
}