package classFiles;

import java.util.*;

public class TaskService {
	private static List<Task> tasks;
	
	//Constructor
	public TaskService() {
		tasks = new ArrayList<> ();
	}
	
	public boolean addTask(Task task) {
		//For all tasks, if task being added has same ID, display error message
		for (Task i: tasks) {
			if (i.getId().equals(task.getId())) {
				System.out.println("Task with same ID already exists");
				return false;
			}
		}
		//If ID is unique, add task
		tasks.add(task);
		System.out.println("Task added");
		return true;
	}
	
	public boolean deleteTask(String id) {
		//For all tasks, if task ID to be deleted is found, delete task associated with ID
		for (Task i: tasks) {
			if (i.getId()== id) {
				tasks.remove(i);
				System.out.println("Task deleted");
				return true;
			}
		}
		//If no matching ID is found, give error message
		System.out.println("Task ID not found");
		return false;
	}
	
	public boolean updateName(String id, String name) {
		for (Task i: tasks) {
			if (i.getId().equals(id)) {
				i.setName(name);
				System.out.println("Name updated");
				return true;
			}
		}
		System.out.println("Task not found");
		return false;
	}
	
	public boolean updateDescription(String id, String description) {
		for (Task i: tasks) {
			if (i.getId().equals(id)) {
				i.setDescription(description);
				System.out.println("Description updated");
				return true;
			}
		}
		System.out.println("Task not found");
		return false;
	}
}