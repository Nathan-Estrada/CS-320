package classFiles;

public class Task {
	//Public declaration of variables
	String id;
	String name;
	String description;
	
	//Constructor
	public Task(String id, String name, String description) {
		if (id == null|| id.length() > 10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		if (name == null ||name.length() > 30 ) {
			throw new IllegalArgumentException("Invalid name");
		}
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid description");
		}
		this.id = id;
		this.setName(name);
		this.setDescription(description);
	}
	
	//Public definition of getters and setters
	public void setName(String name) {
		if (name == null ||name.length() > 30 ) {
			throw new IllegalArgumentException("Invalid name");
		}
		this.name = name;
	}
	public void setDescription(String description) {
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid description");
		}
		this.description = description;
	}
	
	public String getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getDescription() {
		return description;
	}
}
