package testFiles;

import static org.junit.jupiter.api.Assertions.*;
import classFiles.Appointment;
import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AppointmentTest {

	@Test
	//Test to ensure Appointment constructor is working
	void testAppointment() {
		Date date = new Date(2025, 8, 1);
		Appointment appointment = new Appointment("123", date, "Doctor visit");
		assertTrue(appointment.getId().equals("123"));
		assertTrue(appointment.getDate().equals(date));
		assertTrue(appointment.getDescription().equals("Doctor visit"));
	}

	@Test
	//Test to ensure setters are working properly
	void testSetters() {
		Date date = new Date(2025, 8, 1);
		Date date2 = new Date(2026, 9, 2);
		Appointment appointment = new Appointment("123", date, "Doctor visit");
		appointment.setDate(date2);
		appointment.setDescription("Dentist visit");
		assertTrue(appointment.getDate().equals(date2));
		assertTrue(appointment.getDescription().equals("Dentist visit"));
	}
	
	@Test
	//Tests functionality of ID assertion throws
	void testIDAssertions() {
		Date date = new Date(2025, 8, 1);
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			 new Appointment("123456789000", date, "Doctor visit");
		});
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			 new Appointment(null, date, "Doctor visit");
		});
	}
	
	@Test
	//Test functionality of date assertion throws
	void testDateAssertions() {
		Date pastDate = new Date(System.currentTimeMillis() - 1000 * 60 * 60 * 24); //Tests one day ago
		Date presentDate = new Date();
		System.out.println(pastDate);
		System.out.println(presentDate);
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			 new Appointment("123", pastDate, "Doctor visit");
		});
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			 new Appointment("123", null, "Doctor visit");
		});
	}
	
	@Test
	//Test functionality of description assertion throws
	void testDescriptionAssertions() {
		Date date = new Date(2025, 8, 1);
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			 new Appointment("123", date, "Doctor visittttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt");
		});
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			 new Appointment("123", date, null);
		});
	}
}
