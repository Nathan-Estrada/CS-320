package testFiles;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import classFiles.Task;

class TaskTest {

	@Test
	//Test to ensure Test constructor is working
	void testTask() {
		Task task = new Task ("123", "Dishes", "Clean the dishes" );
		assertTrue(task.getId().equals("123"));
		assertTrue(task.getName().equals("Dishes"));
		assertTrue(task.getDescription().equals("Clean the dishes"));
	}

	@Test
	//Test setter functionality
	void testSetters() {
		Task task = new Task ("123", "Dishes", "Clean the dishes" );
		task.setName("Laundry");
		task.setDescription("Wash the laundry");
		assertTrue(task.getName().equals("Laundry"));
		assertTrue(task.getDescription().equals("Wash the laundry"));
	}

	@Test
	//Test assertion throws for task ID being too long or null
	void testIDAssertions() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task ("123333333333333333333333", "Dishes", "Clean the dishes" );
			});
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task (null, "Dishes", "Clean the dishes" );
			});
	}
	
	@Test
	//Test assertion throws for task name being too long or null
	void testNameAssertions() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task ("123", "Dishesssssssssssssssssssssssssssssssssssssssssssssssssssss"
					, "Clean the dishes" );
			});
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task ("123", null, "Clean the dishes" );
			});
	}
	
	@Test
	//Test assertion throws for task description being too long or null
	void testDescriptionAssertions() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task ("123", "Dishes"
					, "Clean the dishesssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss"
							+ "sssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss" );
			});
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task ("123", "Dishes", null );
			});
	}
}
