package testFiles;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import classFiles.Appointment;
import classFiles.AppointmentService;
import org.junit.jupiter.api.Test;


class AppointmentServiceTest {

	@Test
	//Tests functionality for adding an appointment and assertion throw for adding appointment with duplicate ID
	void testAddAppointment() {
		AppointmentService test = new AppointmentService();
		Date date = new Date(2025, 8, 1);
		Appointment appointment1 = new Appointment("123", date, "Doctor visit");
		Appointment appointment2 = new Appointment("123", date, "Dentist visit");
		assertEquals(true, test.addAppointment(appointment1));
		assertEquals(false, test.addAppointment(appointment2)); //False assertion for adding appointment with same ID
	}
	
	@Test
	//Tests functionality for deleting an appointment and assertion throw for deleting an appointment that does not exist in appointments map
	void testDeleteAppointment() {
		AppointmentService test = new AppointmentService();
		Date date = new Date(2025, 8, 1);
		Appointment appointment1 = new Appointment("123", date, "Doctor visit");
		Appointment appointment2 = new Appointment("345", date, "Dentist visit");
		test.addAppointment(appointment1);
		assertEquals(true, test.deleteAppointment(appointment1));
		assertEquals(false, test.deleteAppointment(appointment2));//False assertion for deleting appointment that doesn't exist in appointments
	}

}