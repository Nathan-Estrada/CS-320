package testFiles;

import static org.junit.Assert.assertEquals;
import org.junit.jupiter.api.Test;

import classFiles.TaskService;
import classFiles.Task;

public class TaskServiceTest {
	@Test
	//Tests addTask functionality
	void addTaskTest() {
		TaskService taskTest = new TaskService();
		Task task = new Task("123", "Dishes", "Clean the dishes" );
		assertEquals(true, taskTest.addTask(task));
	}
	
	@Test
	//Testing assertion throw for adding task with same ID
	void addSameTaskIdTest() {
		TaskService taskTest = new TaskService();
		Task task = new Task("123", "Dishes", "Clean the dishes" );
		Task task2 = new Task ("123", "Laundry", "Clean the laundry");
		taskTest.addTask(task);
		assertEquals(false, taskTest.addTask(task2));
	}
	
	@Test
	//Tests deleteTask functionality
	void deleteTaskTest() {
		TaskService taskTest = new TaskService();
		Task task = new Task("123", "Dishes", "Clean the dishes" );
		taskTest.addTask(task);
		assertEquals(true, taskTest.deleteTask("123")); //Checks for deleting existing task
		assertEquals(false, taskTest.deleteTask("321")); //Checks for error on deleting non-existing task
	}
	
	@Test
	//Tests updateName functionality
	void updateNameTest() {
		TaskService taskTest = new TaskService();
		Task task = new Task("123", "Dishes", "Clean the dishes" );
		taskTest.addTask(task);
		//Test passes if task with existing ID updates
		assertEquals(true, taskTest.updateName("123", "Laundry"));
	}
	
	@Test
	//Tests updateDescription functionality
	void updateDescriptionTest() {
		TaskService taskTest = new TaskService();
		Task task = new Task("123", "Dishes", "Clean the dishes" );
		taskTest.addTask(task);
		//Test passes if task with existing ID updates
		assertEquals(true, taskTest.updateDescription("123", "Dry the dishes"));
	}
}